package com.onFit.adm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmApplicationTests {

	@Test
	void contextLoads() {
	}

}
